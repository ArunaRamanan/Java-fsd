package assistedpractice2;
import assistedpracticee2.*;
public class DefaultAccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultFile df=new DefaultFile();
		df.display();

	}

}
