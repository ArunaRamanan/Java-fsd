package assistedpractice2;
import assistedpracticee2.*;
public class PublicAccessModifie {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PublicFile pf=new PublicFile();
		pf.display();
	}

}
