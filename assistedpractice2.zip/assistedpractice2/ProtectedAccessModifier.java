package assistedpractice2;
import assistedpracticee2.*;
public class ProtectedAccessModifier extends ProtectedFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProtectedAccessModifier pa=new ProtectedAccessModifier();
		pa.display();
	}
		

	}


