package assistedpractice2;

class privateModifier{
	void display() {
		System.out.println("This is a Private Class");
	}
}
public class PrivateAccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		privateModifier a=new privateModifier();
		a.display();

}
}