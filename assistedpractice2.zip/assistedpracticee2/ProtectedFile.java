package assistedpracticee2;

public class ProtectedFile {
	protected void display() {
		System.out.println("This is a Protected Class");
	}

}
