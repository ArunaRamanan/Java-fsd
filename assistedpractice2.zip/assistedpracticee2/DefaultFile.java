package assistedpracticee2;

public class DefaultFile {

	public void display() {
		System.out.println("This is a Default Class");
	}

}
