package assistedpracticee2;

public class PublicFile {
	public void display() {
		System.out.println("This is a Public Class");
	}
}
