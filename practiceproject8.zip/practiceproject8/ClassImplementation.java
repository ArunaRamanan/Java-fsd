package practiceproject8;

public class ClassImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(" Class Implemetation is a Class");
	}

}
