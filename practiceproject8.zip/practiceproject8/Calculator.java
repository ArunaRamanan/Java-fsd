package practiceproject8;

public abstract class Calculator {

	public abstract void sum(int value1,int value2);
	public abstract void sub(int value1,int value2);
}
