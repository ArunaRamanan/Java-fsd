package practiceproject6;

public class InvalidScoreException extends Exception  {

	public String toString() {
		return "You have Failed to clear the exam";
	}

}
