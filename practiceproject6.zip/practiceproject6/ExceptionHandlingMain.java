package practiceproject6;

public class ExceptionHandlingMain {

	public static void main(String[] args) throws InvalidScoreException {

		EligibilityValidator eligibility=new EligibilityValidator();
		eligibility.CheckScore(84);
	}
}
