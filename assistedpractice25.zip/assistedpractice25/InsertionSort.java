package assistedpractice25;

import java.util.Arrays;

public class InsertionSort {
    public static void insertionSort(int[] ar) {
        int n = ar.length;

        for (int i = 1; i < n; i++) {
            int key = ar[i];
            int j = i - 1;

            while (j >= 0 && ar[j] > key) {
                ar[j + 1] = ar[j];
                j--;
            }

            ar[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        int[] ar = {60, 20, 40, 80,100,70,10};
        System.out.println("Original array: " + Arrays.toString(ar));

        insertionSort(ar);

        System.out.println("Sorted array: " + Arrays.toString(ar));
    }
}
