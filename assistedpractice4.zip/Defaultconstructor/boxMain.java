package Defaultconstructor;

public class boxMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		box vol=new box();
	}

}
