package Defaultconstructor;

public class box {

	box(){
		double length=50;
		double breadth=20;
		double height=25;
		
		double volume=length*breadth*height;
		System.out.println("the volume of box: "+volume);
	}

}
