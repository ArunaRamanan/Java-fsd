package Parameterizedconstructor;

public class box {

	box(double breadth,double height,double length){
		
		double volume=length*breadth*height;
		System.out.println("the volume of box: "+volume);
		
	}

}
