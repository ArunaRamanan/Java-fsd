package Parameterizedconstructor;

public class boxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		box vol=new box(50,20,25);

	}

}
