package assistedpractice20;

public class LinearSearch {
    public static int ls(int[] ar, int target) {
        for (int x = 0; x < ar.length; x++) {
            if (ar[x] == target) {
                return x;
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        int[] ar = {20,25,30,35,40,45};
        int target =30;

        int index = ls(ar, target);

        if (index != -1) {
            System.out.println("Element found at Index Position " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}