package assistedpractice23;

import java.util.Arrays;

public class SelectionSort {
    public static void selectionSort(int[] ar) {
        int n = ar.length;

        for (int i = 0; i < n-1; i++) {
            int minIndex = i;

            // Find the index of the minimum element in the unsorted portion
            for (int j = i + 1; j < n; j++) {
                if (ar[j] < ar[minIndex]) {
                    minIndex = j;
                }
            }

            // Swap the minimum element with the current element
            int temp = ar[i];
            ar[i] = ar[minIndex];
            ar[minIndex] = temp;
        }
    }

    public static void main(String[] args) {
        int[] ar = {96, 14, 100, 45,10};
        System.out.println("Original array: " + Arrays.toString(ar));

        selectionSort(ar);

        System.out.println("Sorted array: " + Arrays.toString(ar));
    }
}
