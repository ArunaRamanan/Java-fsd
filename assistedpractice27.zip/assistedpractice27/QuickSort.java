package assistedpractice27;

import java.util.Arrays;

public class QuickSort {
    public static void quickSort(int[] ar) {
        if (ar == null || ar.length == 0) {
            return; // Array is already sorted
        }

        int n = ar.length;
        quickSort(ar, 0, n - 1);
    }

    public static void quickSort(int[] ar, int left, int right) {
        if (left < right) {
            int pivotIndex = partition(ar, left, right);

            quickSort(ar, left, pivotIndex - 1);
            quickSort(ar, pivotIndex + 1, right);
        }
    }

    public static int partition(int[] ar, int left, int right) {
        int pivot = ar[right];
        int i = left - 1;

        for (int j = left; j < right; j++) {
            if (ar[j] <= pivot) {
                i++;
                // Swap arr[i] and arr[j]
                int temp = ar[i];
                ar[i] = ar[j];
                ar[j] = temp;
            }
        }

        // Swap arr[i+1] and arr[right] (the pivot)
        int temp = ar[i + 1];
        ar[i + 1] = ar[right];
        ar[right] = temp;

        return i + 1;
    }

    public static void main(String[] args) {
        int[] ar = {60, 20, 40, 80, 100, 70,10};
        System.out.println("Original array: " + Arrays.toString(ar));

        quickSort(ar);

        System.out.println("Sorted array: " + Arrays.toString(ar));
    }
}
