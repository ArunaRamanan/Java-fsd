package assistedpractice11;

public class ArrayRightRotation {
	public static void main(String[] args) {
		int[] arr = {10, 40, 30, 55, 75, 65, 80, 85, 90};
		int steps = 5;

		// Display the given array
		System.out.println("Given Array:");
		for (int num : arr) {
			System.out.print(num + " ");
		}

		// Right rotate the array by 'steps'
		rightRotateArray(arr, steps);

		// Display the rotated array
		System.out.println("\nRotated Array:");
		for (int num : arr) {
			System.out.print(num + " ");
		}
	}

	public static void rightRotateArray(int[] arr, int steps) {
		int length = arr.length;
		//steps = steps % length; // Handle cases where steps are greater than the array length
		int[] temp = new int[steps];

		// Copy the last 'steps' elements to a temporary array
		for (int i = 0; i < steps; i++) {
			temp[i] = arr[length - steps + i]; 
		}

		// Shift the remaining elements to the right
		for (int i = length - 1; i >= steps; i--) {
			arr[i] = arr[i - steps];
		}

		// Copy the temporary array back to the original array
		for (int i = 0; i < steps; i++) {
			arr[i] = temp[i];
		}
	}
}


