package emailvalidationpracticeproject;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class EmailValidation {
 public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);
 System.out.print("Enter an email address: ");
 String email = sc.nextLine();
 boolean isValid = isValidEmail(email);
 if (isValid) {
 System.out.println("The email is valid.");
 } else {
 System.out.println("The email is not valid.");
 }
 }
 public static boolean isValidEmail(String email) {

 String emailPattern = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
 Pattern pattern = Pattern.compile(emailPattern);
 Matcher matcher = pattern.matcher(email);
 return matcher.matches();
 }
}
