package assistedpractice26;

import java.util.Arrays;

public class MergeSort {
    public static void mergeSort(int[] ar) {
        int n = ar.length;
        if (n < 2) {
            return; // Array is already sorted
        }

        int mid = n / 2;
        int[] left = new int[mid];
        int[] right = new int[n - mid];

        // Populate left and right subarrays
        System.arraycopy(ar, 0, left, 0, mid);
        System.arraycopy(ar, mid, right, 0, n - mid);

        // Recursively sort left and right subarrays
        mergeSort(left);
        mergeSort(right);

        // Merge the sorted subarrays
        merge(ar, left, right);
    }

    public static void merge(int[] ar, int[] left, int[] right) {
        int nLeft = left.length;
        int nRight = right.length;
        int i = 0, j = 0, k = 0;

        while (i < nLeft && j < nRight) {
            if (left[i] <= right[j]) {
                ar[k] = left[i];
                i++;
            } else {
                ar[k] = right[j];
                j++;
            }
            k++;
        }

        while (i < nLeft) {
            ar[k] = left[i];
            i++;
            k++;
        }

        while (j < nRight) {
            ar[k] = right[j];
            j++;
            k++;
        }
    }

    public static void main(String[] args) {
        int[] ar = {60, 20, 40, 80,100,70,10};
        System.out.println("Original array: " + Arrays.toString(ar));

        mergeSort(ar);

        System.out.println("Sorted array: " + Arrays.toString(ar));
    }
}
