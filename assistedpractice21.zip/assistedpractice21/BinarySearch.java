package assistedpractice21;

public class BinarySearch {
    public static int binarySearch(int[] ar, int target) {
        int start = 0;
        int end = ar.length - 1;

        while (start <= end) {
            int mid = start + (end - start) / 2;

            if (ar[mid] == target) {
                return mid; // Element found, return its in
            } else if (ar[mid] < target) {
                start = mid + 1; // Adjust the start bound
            } else {
                end = mid - 1; // Adjust the end bound
            }
        }
        return -1; // Element not found, return -1
    }

    public static void main(String[] args) {
        int[] ar = {20, 25, 30, 35, 40,45};
        int target =30;

        int index = binarySearch(ar, target);

        if (index != -1) {
            System.out.println("Element found at Index Position  " + index);
        } else {
            System.out.println("Element is not found in the array.");
        }
    }
}
