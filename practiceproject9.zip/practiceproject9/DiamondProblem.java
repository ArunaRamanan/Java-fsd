package practiceproject9;

interface A{
	default void star() {

		System.out.println("Hi guys I am the Star");
	}
}


interface B{
	default void star() {

		System.out.println("Star twinkling Everyday in the night");

	}
}

class C implements A,B{
	public void star() {
		A.super.star();
		B.super.star();
	}

}

public class DiamondProblem {

	public static void main(String[] args) {

		C obj=new C();
		obj.star();
	}

}


