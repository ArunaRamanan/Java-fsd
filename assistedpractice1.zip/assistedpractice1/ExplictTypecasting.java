package assistedpractice1;
import java.util.Scanner;
public class ExplictTypecasting {

		// TODO Auto-generated method stub
		public void convert(double v) {
			int explict= (int) v;
			
			System.out.println("Conversion of Double to Integer (Narrowing)  "+explict);
			
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub

			ExplictTypecasting exp=new ExplictTypecasting();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter an Double Value: ");
			double var=sc.nextDouble();
			exp.convert(var);

	}

}