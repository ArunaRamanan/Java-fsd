package assistedpractice1;
import java.util.Scanner;
public class ImplictTypecasting {


	public void convert(int v) {
		double implict= v;
		
		System.out.println("Conversion of Integer to Double (Widening)  "+implict);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ImplictTypecasting imp=new ImplictTypecasting();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an Integer Value: ");
		int var=sc.nextInt();
		imp.convert(var);
	}

}

