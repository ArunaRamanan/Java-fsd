/**
 * 
 */
/**
 * 
 */
module Phase2practiceproject6 {
	requires java.sql;
	
}