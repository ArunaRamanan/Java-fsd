/**
 * 
 */
/**
 * 
 */
module Phase2practiceproject5 {
	requires java.sql;
}