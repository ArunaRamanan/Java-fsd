package practiceproject5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class DBCrudOp 
{
public static void main(String[] args) throws ClassNotFoundException, SQLException
{
	final String DRIVER_CLASS="com.mysql.cj.jdbc.Driver";
    final String DB_URL="jdbc:mysql://localhost:3306/jdbccrud";
	final String USERNAME="root";
	final String PASSWORD="Indumathi123$";
	Class.forName(DRIVER_CLASS);
	//connection with the dB 
	Connection con=DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
	Statement st=con.createStatement();
	//create a database
		st.execute("create database jdbc");
		//select a database
		st.execute("use jdbc");
		//drop a database
		st.execute("drop database jdbc");
		con.close();
	con.close();
	
 	
	
}
}