/**
 * 
 */
/**
 * 
 */
module Phase2practiceproject3 {
	requires java.sql;
}