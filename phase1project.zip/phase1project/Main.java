package phase1project;
public class Main {
public static void main(String[] args) {
CameraRentalApplication app = new CameraRentalApplication();
app.run();
}
}
