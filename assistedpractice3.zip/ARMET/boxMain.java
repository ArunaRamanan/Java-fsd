package ARMET;

public class boxMain {
	public static void main(String[] args) {
		box details=new box();
		details.volume(15,10,20);

	}
}
