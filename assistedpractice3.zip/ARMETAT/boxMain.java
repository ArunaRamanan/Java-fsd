package ARMETAT;

public class boxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		box details=new box();
		details.length=20;
		details.height=30;
		details.breadth=25;
		details.volume();
	}
}
