package ARME;

public class boxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		box details=new box();
		double volume=details.volume(45,25,40);

		System.out.println("The Volume of box :"+volume);

	}

}
