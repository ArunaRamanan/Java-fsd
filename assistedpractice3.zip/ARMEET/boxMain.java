package ARMEET;

public class boxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		box details=new box();

		details.length=5;
		details.breadth=2;
		details.height=10;
		double volume=details.volume();
		System.out.println("Volume is "+volume);


	}

}
