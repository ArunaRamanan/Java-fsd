package calculatorpracticeproject;
import java.util.Scanner;
public class ArithmeticCalculatorProgram {
 public static void main(String[] args) {
 Scanner sc = new Scanner(System.in);
 System.out.println("welcome to Arithmetic Calculator");
 double result = 0;
 System.out.print("Enter the first number: ");
 double a1 = sc.nextDouble();
 System.out.print("Enter the second number: ");
 double a2 = sc.nextDouble();
 System.out.println("\nSelect an operation:");
 System.out.println("1. Addition (+)");
 System.out.println("2. Subtraction (-)");
 System.out.println("3. Multiplication (*)");
 System.out.println("4. Division (/)");
 System.out.print("Enter your choice : ");
 char choice = sc.next().charAt(0);
 switch (choice) {
 case '+':
 result = a1 + a2;
 System.out.println("Result: " + a1 + " + " + a2 +
" = " + result);
 break;
 case '-':
 result = a1 - a2;
 System.out.println("Result: " + a1 + " - " + a2 +
" = " + result);
 break;
 case '*':
 result = a1 * a2;
 System.out.println("Result: " + a1 + " * " + a2 +
" = " + result);
 break;
 case '/':
 if (a2 != 0) {
 result = a1 / a2;
 System.out.println("Result: " + a1 + " / " +
a2 + " = " + result);
 } else {
 System.out.println("Cannot divide by zero");
 }
 break;
 default:
 System.out.println("Invalid choice!");
 }

 }
}