package assistedpractice12;

import java.util.Arrays;

public class FourthSmallestElement 
{
public static void main(String[] args)
{
int[] unsortedList= {15,27,90,28,50,30,10};
int fourthSmallest=findFourthSmallest(unsortedList);
System.out.println("The fourth smallest element is: "+fourthSmallest);
}

public static int findFourthSmallest(int[] arr) 
{
if(arr.length<4)	
{
	return -1;
}
Arrays.sort(arr);
return arr[3];
}
}
